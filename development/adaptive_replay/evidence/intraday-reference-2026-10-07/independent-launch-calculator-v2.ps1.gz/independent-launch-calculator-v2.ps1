[CmdletBinding()]
param(
    [string]$ResultRoot = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a',
    [string]$PlanPath = 'D:\Kairos\kairos\development\adaptive_replay\intraday-source-plan.json',
    [string]$LaunchPath = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a.launch.json',
    [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$expectedPlanSha = '89e1a6641e228365ffec5011da2f456f6af67d3a83d46ccfe037ff0f360f6748'
$expectedCommit = '0dee566dd392ff2e969db3aff43d1f1126790c2e'
$expectedSigner = '40AF365C6682B73D056A6A274DBFF6B65BE9F827'
$publicRoot = 'https://data.binance.vision/data/futures/um/daily/aggTrades'
$expectedCi = @(
    [pscustomobject]@{ run_id = 37573651611L; workflow = 'adaptive-development'; conclusion = 'success' },
    [pscustomobject]@{ run_id = 37573651603L; workflow = 'validate'; conclusion = 'success' },
    [pscustomobject]@{ run_id = 37573651296L; workflow = 'Push on main / CodeQL'; conclusion = 'success' }
)

function Stop-Audit([string]$Message) { throw "Launch binding v2 failed: $Message" }
function Get-Sha256([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Require-Equal($Actual, $Expected, [string]$Label) {
    if ($Actual -cne $Expected) { Stop-Audit "$Label mismatch (actual='$Actual', expected='$Expected')" }
}
function Get-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { Stop-Audit "required file missing: $Path" }
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}
function Get-RawJsonString([string]$Path, [string]$PropertyName) {
    $jsonText = [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8)
    $document = [System.Text.Json.JsonDocument]::Parse($jsonText)
    try {
        return $document.RootElement.GetProperty($PropertyName).GetString()
    } finally {
        $document.Dispose()
    }
}
function Parse-UtcInstant([string]$RawValue, [string]$Label) {
    $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
    $parsed = [DateTimeOffset]::Parse($RawValue, [Globalization.CultureInfo]::InvariantCulture, $styles)
    if ($parsed.Offset -ne [TimeSpan]::Zero) { Stop-Audit "$Label did not normalize to UTC" }
    return $parsed
}
function Format-UtcInstant([DateTimeOffset]$Value) {
    $Value.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'", [Globalization.CultureInfo]::InvariantCulture)
}
function ConvertTo-CanonicalNode($Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $ordered = [ordered]@{}
        foreach ($name in @($Value.PSObject.Properties.Name | Sort-Object -CaseSensitive)) {
            $ordered[$name] = ConvertTo-CanonicalNode $Value.$name
        }
        return $ordered
    }
    if ($Value -is [System.Collections.IDictionary]) {
        $ordered = [ordered]@{}
        foreach ($name in @($Value.Keys | Sort-Object -CaseSensitive)) {
            $ordered[[string]$name] = ConvertTo-CanonicalNode $Value[$name]
        }
        return $ordered
    }
    if ($Value -is [System.Array] -or ($Value -is [System.Collections.IList] -and $Value -isnot [string])) {
        $items = [Collections.Generic.List[object]]::new()
        foreach ($item in $Value) { $items.Add((ConvertTo-CanonicalNode $item)) }
        return ,$items.ToArray()
    }
    return $Value
}
function Get-CanonicalJson($Value) {
    ConvertTo-Json -InputObject (ConvertTo-CanonicalNode $Value) -Depth 100 -Compress
}

$root = [IO.Path]::GetFullPath($ResultRoot)
$planFile = [IO.Path]::GetFullPath($PlanPath)
$launchFile = [IO.Path]::GetFullPath($LaunchPath)
$oldReceiptPath = Join-Path $root 'independent-launch-binding.json'
$oldScriptPath = 'D:\Kairos\runtime\Audit-IntradayLaunchBinding-20261007.ps1'
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $output = Join-Path $root 'independent-launch-binding-v2.json'
} else {
    $output = [IO.Path]::GetFullPath($OutputPath)
}
if (-not (Test-Path -LiteralPath $root -PathType Container)) { Stop-Audit 'attempt output directory is missing' }
if ([IO.Path]::GetDirectoryName($output) -ne $root) { Stop-Audit 'output must be a direct child of ResultRoot' }
if (Test-Path -LiteralPath $output) { Stop-Audit 'create-only v2 output already exists' }

$actualPlan = Get-Json $planFile
$sealedPlan = Get-Json (Join-Path $root 'sealed-source-plan.json')
$launch = Get-Json $launchFile
$beforePath = Join-Path $root 'before.json'
$failurePath = Join-Path $root 'failure.json'
$before = Get-Json $beforePath
$failure = Get-Json $failurePath
$partialAudit = Get-Json (Join-Path $root 'independent-partial-witness-audit.json')
$oldReceipt = Get-Json $oldReceiptPath

$planSha = Get-Sha256 $planFile
$sealedSha = Get-Sha256 (Join-Path $root 'sealed-source-plan.json')
$launchSha = Get-Sha256 $launchFile
$oldReceiptSha = Get-Sha256 $oldReceiptPath
$oldScriptSha = Get-Sha256 $oldScriptPath
$partialAuditSha = Get-Sha256 (Join-Path $root 'independent-partial-witness-audit.json')
$partialAuditorSha = Get-Sha256 'D:\Kairos\runtime\Audit-PartialIntradayReferences-20261007.ps1'

Require-Equal $planSha $expectedPlanSha 'actual source plan raw SHA256'
Require-Equal ([string]$launch.source_plan_file_sha256) $planSha 'launch raw source-plan binding'
if ((Get-CanonicalJson $actualPlan) -cne (Get-CanonicalJson $sealedPlan)) {
    Stop-Audit 'sealed plan is not semantically equal to actual source plan'
}
Require-Equal ([string]$launch.schema) 'kairos.source-only.launch-proof.v1' 'launch proof schema'
Require-Equal ([string]$launch.source_commit) $expectedCommit 'launch source commit'
Require-Equal ([string]$launch.verified_gpg_signer) $expectedSigner 'launch declared GPG signer'
Require-Equal ([string]$launch.purpose) 'SOURCE_ONLY_PRINT_REFERENCES_NOT_EXECUTION_ECONOMICS_OR_ALPHA' 'launch purpose'
if ([int]$launch.attempt -ne 1) { Stop-Audit 'launch attempt must be one' }
if ($launch.readiness_unchanged -ne $true) { Stop-Audit 'launch readiness_unchanged marker must be true' }

$ci = @($launch.exact_source_ci)
if ($ci.Count -ne 3) { Stop-Audit 'exactly three prior CI success witnesses are required' }
for ($i = 0; $i -lt 3; $i++) {
    Require-Equal ([long]$ci[$i].run_id) ([long]$expectedCi[$i].run_id) "CI run ID $i"
    Require-Equal ([string]$ci[$i].workflow) ([string]$expectedCi[$i].workflow) "CI workflow $i"
    Require-Equal ([string]$ci[$i].conclusion) 'success' "CI conclusion $i"
}

$expectedNames = [Collections.Generic.List[string]]::new()
for ($i = 0; $i -lt 8; $i++) {
    $archive = $actualPlan.archives[$i]
    $zipName = "$($archive.symbol)-aggTrades-$($archive.day).zip"
    $expectedNames.Add("$zipName.CHECKSUM")
    $expectedNames.Add($zipName)
}
for ($i = 1; $i -le 8; $i++) {
    $downloads = @(Get-Json (Join-Path $root ("downloads-{0:D2}.json" -f $i)))
    if ($downloads.Count -ne 2) { Stop-Audit "download receipt $i must have exactly checksum+ZIP" }
    for ($j = 0; $j -lt 2; $j++) {
        $position = (($i - 1) * 2) + $j
        $filename = [string]$expectedNames[$position]
        Require-Equal ([string]$downloads[$j].filename) $filename "first-eight filename/order $position"
        $parts = $filename -split '-aggTrades-', 2
        Require-Equal ([string]$downloads[$j].url) "$publicRoot/$($parts[0])/$filename" "first-eight URL $position"
    }
}

# Read UTC timestamp strings directly from JSON tokens; avoid ConvertFrom-Json DateTime/local coercion.
$rawNotBefore = Get-RawJsonString $launchFile 'not_before_utc'
$rawStarted = Get-RawJsonString $beforePath 'started_utc'
$rawFailed = Get-RawJsonString $failurePath 'completed_utc'
$oldDisplayedNotBeforeRaw = Get-RawJsonString $oldReceiptPath 'launch_not_before_utc'
$notBefore = Parse-UtcInstant $rawNotBefore 'launch.not_before_utc'
$started = Parse-UtcInstant $rawStarted 'before.started_utc'
$failed = Parse-UtcInstant $rawFailed 'failure.completed_utc'
if (-not ($notBefore -le $started -and $started -lt $failed)) { Stop-Audit 'UTC launch/start/failure instants are out of order' }
$roundtripNotBefore = Format-UtcInstant $notBefore
$roundtripStarted = Format-UtcInstant $started
$roundtripFailed = Format-UtcInstant $failed
$expectedNotBefore = [DateTimeOffset]::Parse($rawNotBefore, [Globalization.CultureInfo]::InvariantCulture, ([Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal))
if ($notBefore.UtcTicks -ne $expectedNotBefore.UtcTicks) { Stop-Audit 'not-before UTC ticks failed exact round-trip' }

Require-Equal ([string]$partialAudit.state) 'PASSED_PARTIAL_WITNESSES' 'existing partial audit state'
Require-Equal ([string]$partialAudit.auditor_sha256) $partialAuditorSha 'partial auditor hash binding'
if ($partialAudit.source_prerequisite_resolved -ne $false -or $partialAudit.complete -ne $false) {
    Stop-Audit 'existing partial receipt must remain incomplete and unresolved'
}
Require-Equal ([string]$oldReceipt.state) 'PASSED_LAUNCH_BOOKKEEPING_ONLY' 'old launch receipt state'
Require-Equal ([string]$oldReceipt.launch_proof_sha256) $launchSha 'old receipt launch hash binding'

$receipt = [ordered]@{
    schema = 'kairos.adaptive.independent-intraday-launch-binding-v2.v1'
    state = 'PASSED_SUPPLEMENTAL_LAUNCH_BINDING_V2'
    scope = 'Corrected launch bookkeeping only; source prerequisite and completeness remain false.'
    launch_proof_sha256 = $launchSha
    launch_source_commit = [string]$launch.source_commit
    declared_verified_gpg_signer = [string]$launch.verified_gpg_signer
    actual_source_plan_raw_sha256 = $planSha
    sealed_plan_raw_sha256 = $sealedSha
    sealed_plan_semantically_equal_to_actual = $true
    exact_successful_prior_ci_runs = @($ci | ForEach-Object { [pscustomobject]@{ run_id = $_.run_id; workflow = $_.workflow; conclusion = $_.conclusion } })
    first_eight_get_filenames_in_order = @($expectedNames)
    timestamps_raw_utc = [ordered]@{
        launch_not_before_utc = $rawNotBefore
        attempt_started_utc = $rawStarted
        attempt_failed_utc = $rawFailed
    }
    timestamps_parsed_and_roundtripped_utc = [ordered]@{
        launch_not_before_utc = $roundtripNotBefore
        attempt_started_utc = $roundtripStarted
        attempt_failed_utc = $roundtripFailed
    }
    timestamps_order_valid = $true
    correction = [ordered]@{
        prior_report_path = $oldReceiptPath
        prior_report_sha256 = $oldReceiptSha
        prior_calculator_path = $oldScriptPath
        prior_calculator_sha256 = $oldScriptSha
        prior_report_displayed_not_before_utc = $oldDisplayedNotBeforeRaw
        raw_launch_not_before_utc = $rawNotBefore
        correction_reason = 'Prior PowerShell ConvertFrom-Json DateTime-to-string conversion shifted the displayed UTC instant by the local UTC+03 offset. Original script/report remain unchanged; v2 reads raw JSON string tokens.'
    }
    prior_partial_audit_sha256 = $partialAuditSha
    prior_partial_auditor_sha256 = $partialAuditorSha
    prior_partial_audit_launch_field_scope = 'launch_artifact_present=false referred only to a root-local launch.json; it did not claim sibling launch absence.'
    source_prerequisite_resolved = $false
    complete_source_coverage = $false
    economics_computed = $false
    qualification_or_promotion_credit = $false
    limitations = @(
        'This receipt closes launch bookkeeping only and does not repair the failed source attempt or verify the failed archive prefix.',
        'Signer fingerprint and prior CI outcomes are asserted from the byte-bound launch proof; no GPG/GitHub re-query was performed.',
        'No network, scanner, parser, archive decompression, or economic replay was performed.'
    )
    audited_utc = [DateTimeOffset]::UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'", [Globalization.CultureInfo]::InvariantCulture)
}

$json = ConvertTo-Json -InputObject $receipt -Depth 16
$stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
    try { $writer.WriteLine($json) } finally { $writer.Dispose() }
} finally { if ($stream) { $stream.Dispose() } }
Write-Output 'Launch binding v2: PASSED_SUPPLEMENTAL_LAUNCH_BINDING_V2'
Write-Output "Receipt: $output"
Write-Output "Raw UTC instants: $rawNotBefore <= $rawStarted < $rawFailed"

[CmdletBinding()]
param(
    [string]$ResultRoot = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a',
    [string]$PlanPath = 'D:\Kairos\kairos\development\adaptive_replay\intraday-source-plan.json',
    [string]$LaunchPath = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a.launch.json',
    [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$expectedPlanSha = '89e1a6641e228365ffec5011da2f456f6af67d3a83d46ccfe037ff0f360f6748'
$expectedCommit = '0dee566dd392ff2e969db3aff43d1f1126790c2e'
$expectedSigner = '40AF365C6682B73D056A6A274DBFF6B65BE9F827'
$publicRoot = 'https://data.binance.vision/data/futures/um/daily/aggTrades'
$expectedCi = @(
    [pscustomobject]@{ run_id = 37573651611L; workflow = 'adaptive-development'; conclusion = 'success' },
    [pscustomobject]@{ run_id = 37573651603L; workflow = 'validate'; conclusion = 'success' },
    [pscustomobject]@{ run_id = 37573651296L; workflow = 'Push on main / CodeQL'; conclusion = 'success' }
)

function Stop-Audit([string]$Message) { throw "Launch binding audit failed: $Message" }
function Get-Sha256([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Require-Equal($Actual, $Expected, [string]$Label) {
    if ($Actual -cne $Expected) { Stop-Audit "$Label mismatch (actual='$Actual', expected='$Expected')" }
}
function Get-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { Stop-Audit "required file missing: $Path" }
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}
function ConvertTo-CanonicalNode($Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $ordered = [ordered]@{}
        foreach ($name in @($Value.PSObject.Properties.Name | Sort-Object -CaseSensitive)) {
            $ordered[$name] = ConvertTo-CanonicalNode $Value.$name
        }
        return $ordered
    }
    if ($Value -is [System.Collections.IDictionary]) {
        $ordered = [ordered]@{}
        foreach ($name in @($Value.Keys | Sort-Object -CaseSensitive)) {
            $ordered[[string]$name] = ConvertTo-CanonicalNode $Value[$name]
        }
        return $ordered
    }
    if ($Value -is [System.Array] -or ($Value -is [System.Collections.IList] -and $Value -isnot [string])) {
        $items = [Collections.Generic.List[object]]::new()
        foreach ($item in $Value) { $items.Add((ConvertTo-CanonicalNode $item)) }
        return ,$items.ToArray()
    }
    return $Value
}
function Get-CanonicalJson($Value) {
    ConvertTo-Json -InputObject (ConvertTo-CanonicalNode $Value) -Depth 100 -Compress
}

$root = [IO.Path]::GetFullPath($ResultRoot)
$planFile = [IO.Path]::GetFullPath($PlanPath)
$launchFile = [IO.Path]::GetFullPath($LaunchPath)
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $output = Join-Path $root 'independent-launch-binding.json'
} else {
    $output = [IO.Path]::GetFullPath($OutputPath)
}
if (-not (Test-Path -LiteralPath $root -PathType Container)) { Stop-Audit 'partial attempt directory is missing' }
if ([IO.Path]::GetDirectoryName($output) -ne $root) { Stop-Audit 'output must be a direct child of ResultRoot' }
if (Test-Path -LiteralPath $output) { Stop-Audit 'create-only output already exists' }

$actualPlan = Get-Json $planFile
$sealedPath = Join-Path $root 'sealed-source-plan.json'
$sealedPlan = Get-Json $sealedPath
$launch = Get-Json $launchFile
$before = Get-Json (Join-Path $root 'before.json')
$failure = Get-Json (Join-Path $root 'failure.json')
$partialAuditPath = Join-Path $root 'independent-partial-witness-audit.json'
$partialAudit = Get-Json $partialAuditPath
$partialAuditorPath = 'D:\Kairos\runtime\Audit-PartialIntradayReferences-20261007.ps1'

$planSha = Get-Sha256 $planFile
$sealedSha = Get-Sha256 $sealedPath
$launchSha = Get-Sha256 $launchFile
$partialAuditSha = Get-Sha256 $partialAuditPath
$partialAuditorSha = Get-Sha256 $partialAuditorPath
Require-Equal $planSha $expectedPlanSha 'actual plan raw SHA256'
Require-Equal ([string]$launch.source_plan_file_sha256) $planSha 'launch-bound raw plan SHA256'
Require-Equal ([string]$launch.source_plan_file_sha256) $expectedPlanSha 'launch fixed source plan SHA256'
if ((Get-CanonicalJson $actualPlan) -cne (Get-CanonicalJson $sealedPlan)) {
    Stop-Audit 'sealed attempt plan is not semantically equal to current source plan'
}
Require-Equal ([string]$launch.schema) 'kairos.source-only.launch-proof.v1' 'launch proof schema'
Require-Equal ([string]$launch.source_commit) $expectedCommit 'source commit'
Require-Equal ([string]$launch.verified_gpg_signer) $expectedSigner 'declared verified GPG signer fingerprint'
Require-Equal ([string]$launch.purpose) 'SOURCE_ONLY_PRINT_REFERENCES_NOT_EXECUTION_ECONOMICS_OR_ALPHA' 'launch purpose'
if ([int]$launch.attempt -ne 1) { Stop-Audit 'launch attempt must be first and sole attempt' }
Require-Equal ([string]$launch.readiness_unchanged) 'True' 'launch readiness unchanged marker'

$launchCi = @($launch.exact_source_ci)
if ($launchCi.Count -ne 3) { Stop-Audit 'launch must bind exactly three prior successful CI runs' }
for ($i = 0; $i -lt 3; $i++) {
    Require-Equal ([long]$launchCi[$i].run_id) ([long]$expectedCi[$i].run_id) "CI run ID $i"
    Require-Equal ([string]$launchCi[$i].workflow) ([string]$expectedCi[$i].workflow) "CI workflow $i"
    Require-Equal ([string]$launchCi[$i].conclusion) 'success' "CI conclusion $i"
}

$expectedNames = [Collections.Generic.List[string]]::new()
for ($i = 0; $i -lt 8; $i++) {
    $item = $actualPlan.archives[$i]
    $baseName = "$($item.symbol)-aggTrades-$($item.day).zip"
    $expectedNames.Add("$baseName.CHECKSUM")
    $expectedNames.Add($baseName)
}
for ($i = 1; $i -le 8; $i++) {
    $downloadPath = Join-Path $root ("downloads-{0:D2}.json" -f $i)
    $downloads = @(Get-Json $downloadPath)
    if ($downloads.Count -ne 2) { Stop-Audit "download receipt $i does not have two witnesses" }
    for ($j = 0; $j -lt 2; $j++) {
        $position = (($i - 1) * 2) + $j
        Require-Equal ([string]$downloads[$j].filename) $expectedNames[$position] "fixed first-eight filename position $position"
        $parts = [string]$expectedNames[$position] -split '-aggTrades-', 2
        $symbol = $parts[0]
        $expectedUrl = "$publicRoot/$symbol/$($expectedNames[$position])"
        Require-Equal ([string]$downloads[$j].url) $expectedUrl "fixed first-eight URL position $position"
    }
}

$beforeUtc = [DateTimeOffset]::Parse([string]$before.started_utc).ToUniversalTime()
$failureUtc = [DateTimeOffset]::Parse([string]$failure.completed_utc).ToUniversalTime()
$notBeforeUtc = [DateTimeOffset]::Parse([string]$launch.not_before_utc).ToUniversalTime()
if (-not ($notBeforeUtc -le $beforeUtc -and $beforeUtc -lt $failureUtc)) {
    Stop-Audit 'launch not-before/start/failure timestamps are not in required order'
}

Require-Equal ([string]$partialAudit.state) 'PASSED_PARTIAL_WITNESSES' 'prior partial audit state'
Require-Equal ([string]$partialAudit.auditor_sha256) $partialAuditorSha 'partial auditor self-hash binding'
Require-Equal ([string]$partialAudit.source_prerequisite_resolved) 'False' 'partial audit source prerequisite marker'
Require-Equal ([string]$partialAudit.complete) 'False' 'partial audit completeness marker'
if ($partialAudit.launch_artifact_present -ne $false) { Stop-Audit 'prior partial audit root-local launch.json marker changed' }

$receipt = [ordered]@{
    schema = 'kairos.adaptive.independent-intraday-launch-binding.v1'
    state = 'PASSED_LAUNCH_BOOKKEEPING_ONLY'
    scope = 'Binds launch metadata and partial-attempt timeline only; does not complete source, integrity, or economic prerequisites.'
    launch_proof_sha256 = $launchSha
    launch_source_commit = [string]$launch.source_commit
    declared_verified_gpg_signer = [string]$launch.verified_gpg_signer
    actual_source_plan_raw_sha256 = $planSha
    sealed_plan_raw_sha256 = $sealedSha
    launch_bound_source_plan_sha256 = [string]$launch.source_plan_file_sha256
    sealed_plan_semantically_equal_to_actual = $true
    exact_successful_prior_ci_runs = @($launchCi | ForEach-Object { [pscustomobject]@{ run_id = $_.run_id; workflow = $_.workflow; conclusion = $_.conclusion } })
    first_eight_get_filenames_in_order = @($expectedNames)
    launch_not_before_utc = $notBeforeUtc.ToString('o')
    attempt_started_utc = $beforeUtc.ToString('o')
    attempt_failed_utc = $failureUtc.ToString('o')
    existing_partial_auditor_sha256 = $partialAuditorSha
    existing_partial_audit_sha256 = $partialAuditSha
    prior_partial_audit_claim_scope = 'launch_artifact_present=false meant no root-local launch.json; it did not assert absence of the sibling launch file.'
    source_prerequisite_resolved = $false
    complete_source_coverage = $false
    economics_computed = $false
    qualification_or_promotion_credit = $false
    limitations = @(
        'This supplementary receipt closes launch bookkeeping only; it does not repair the failed row-limit source attempt or verify missing archive rows.',
        'The signer fingerprint and CI run outcomes are checked against the launch proof JSON, not re-queried from GPG/GitHub.',
        'No source scanner, network/API, archive parser, or economic replay was run.'
    )
    audited_utc = [DateTimeOffset]::UtcNow.ToString('o')
}

$json = ConvertTo-Json -InputObject $receipt -Depth 12
$stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
    try { $writer.WriteLine($json) } finally { $writer.Dispose() }
} finally { if ($stream) { $stream.Dispose() } }
Write-Output 'Launch binding: PASSED_LAUNCH_BOOKKEEPING_ONLY'
Write-Output "Receipt: $output"
Write-Output "Plan SHA256: $planSha; CI witnesses: $($launchCi.Count); launch ordering: valid"

$ErrorActionPreference = 'Stop'
$taskRepo = 'D:\Kairos\kairos'
$taskOutput = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a'
$taskStdout = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a.stdout.log'
$taskStderr = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a.stderr.log'
$taskPython = 'D:\Kairos\runtime\native-observation-import-20261006\py311\Scripts\python.exe'
if ((git -C $taskRepo rev-parse HEAD) -cne '0dee566dd392ff2e969db3aff43d1f1126790c2e' -or
    (git -C $taskRepo rev-parse origin/main) -cne '0dee566dd392ff2e969db3aff43d1f1126790c2e' -or
    (git -C $taskRepo branch --show-current) -cne 'main' -or
    @(git -C $taskRepo status --porcelain).Count) { throw 'Signed clean source gate changed.' }
$taskActive = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^python' -and $_.CommandLine -match '-m\s+adaptive_replay\.intraday_audit'
})
if ($taskActive.Count) { throw 'Exact source worker already exists; no duplicate.' }
foreach ($taskPath in @($taskOutput, $taskStdout, $taskStderr)) {
    if (Test-Path -LiteralPath $taskPath) { throw 'Fresh source attempt/output required, no retry.' }
}
foreach ($taskModule in @('intraday_audit.py', 'intraday_references.py')) {
    $taskWorkingHash = (Get-FileHash -LiteralPath (Join-Path "$taskRepo\development\adaptive_replay\adaptive_replay" $taskModule) -Algorithm SHA256).Hash
    $taskInstalledHash = (Get-FileHash -LiteralPath (Join-Path 'D:\Kairos\runtime\native-observation-import-20261006\py311\Lib\site-packages\adaptive_replay' $taskModule) -Algorithm SHA256).Hash
    if ($taskWorkingHash -cne $taskInstalledHash) { throw 'Installed noneditable source differs from signed source.' }
}
$taskRuns = @(gh run list --repo Kairos-cryptoAI/kairos --commit 0dee566dd392ff2e969db3aff43d1f1126790c2e --limit 8 --json databaseId,headSha,status,conclusion | ConvertFrom-Json)
if ($LASTEXITCODE) { throw 'Cannot verify exact source CI.' }
foreach ($taskRunId in @(37573651611,37573651603,37573651296)) {
    $taskRun = @($taskRuns | Where-Object { $_.databaseId -eq $taskRunId })
    if ($taskRun.Count -ne 1 -or $taskRun[0].status -cne 'completed' -or $taskRun[0].conclusion -cne 'success' -or
        $taskRun[0].headSha -cne '0dee566dd392ff2e969db3aff43d1f1126790c2e') { throw 'Exact source CI not green.' }
}
$taskArgs = @('-m','adaptive_replay.intraday_audit','--plan',
    'D:\Kairos\kairos\development\adaptive_replay\intraday-source-plan.json',
    '--native-root','D:\Kairos\runtime\adaptive-development-20261006\bounded-20261006-b',
    '--output',$taskOutput)
$taskProcess = Start-Process -FilePath $taskPython -ArgumentList $taskArgs -WorkingDirectory 'D:\Kairos\runtime' -WindowStyle Hidden -PassThru -RedirectStandardOutput $taskStdout -RedirectStandardError $taskStderr
Write-Output "Started the sole bounded source-only worker PID=$($taskProcess.Id)."
if (-not $taskProcess.WaitForExit(900000)) {
    $taskProcess.Kill()
    throw 'Owned source-only worker reached the 900-second hard wall; no retry.'
}
$taskProcess.Refresh()
if ($taskProcess.ExitCode -ne 0) { throw 'Source-only attempt failed closed; retained receipts, no retry.' }
Get-Content -LiteralPath $taskStdout -Tail 8
Write-Output 'Bounded source-only worker exited successfully.'

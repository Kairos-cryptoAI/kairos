[CmdletBinding()]
param(
    [string]$ResultRoot = 'D:\Kairos\runtime\intraday-reference-audit-20261007-a',
    [string]$PlanPath = 'D:\Kairos\kairos\development\adaptive_replay\intraday-source-plan.json',
    [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$expectedPlanSha256 = '89e1a6641e228365ffec5011da2f456f6af67d3a83d46ccfe037ff0f360f6748'
$nativeRoot = 'D:\Kairos\runtime\adaptive-development-20261006\bounded-20261006-b'
$publicRoot = 'https://data.binance.vision/data/futures/um/daily/aggTrades'
$allowedStatuses = @(
    'RECORDED_PRINT_REFERENCE',
    'NO_RECORDED_PRINT_IN_ASSUMED_WINDOW',
    'GAP_TAINTED',
    'BOUNDARY_UNPROVEN',
    'EXPIRED_BEFORE_ARRIVAL'
)

function Stop-Audit([string]$Message) { throw "Partial witness audit failed: $Message" }
function Get-Sha256([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Require-Equal($Actual, $Expected, [string]$Label) {
    if ($Actual -cne $Expected) { Stop-Audit "$Label mismatch (actual='$Actual', expected='$Expected')" }
}
function Require-False($Value, [string]$Label) {
    if ($null -eq $Value -or $Value -isnot [bool] -or $Value) { Stop-Audit "$Label must be explicitly false" }
}
function Get-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { Stop-Audit "required JSON missing: $Path" }
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}
function Get-Property($Object, [string]$Name, [string]$Context) {
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { Stop-Audit "$Context missing property '$Name'" }
    return $property.Value
}
function Test-PositiveDecimal($Value) {
    $parsed = [decimal]0
    return [decimal]::TryParse(
        [string]$Value,
        [Globalization.NumberStyles]::Float,
        [Globalization.CultureInfo]::InvariantCulture,
        [ref]$parsed
    ) -and $parsed -gt 0
}

$root = [IO.Path]::GetFullPath($ResultRoot)
$planFile = [IO.Path]::GetFullPath($PlanPath)
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $output = Join-Path $root 'independent-partial-witness-audit.json'
} else {
    $output = [IO.Path]::GetFullPath($OutputPath)
}
if (-not (Test-Path -LiteralPath $root -PathType Container)) { Stop-Audit 'attempt output directory is missing' }
if ([IO.Path]::GetDirectoryName($output) -ne $root) { Stop-Audit 'output must be a direct child of ResultRoot' }
if (Test-Path -LiteralPath $output) { Stop-Audit 'create-only audit output already exists' }
if (-not (Test-Path -LiteralPath $planFile -PathType Leaf)) { Stop-Audit 'fixed source plan is missing' }
Require-Equal (Get-Sha256 $planFile) $expectedPlanSha256 'fixed plan SHA256'

$evidenceFiles = [Collections.Generic.List[object]]::new()
function Record-JsonEvidence([string]$Path, [string]$Label) {
    $evidenceFiles.Add([pscustomobject]@{ name = $Label; sha256 = (Get-Sha256 $Path); bytes = (Get-Item -LiteralPath $Path).Length })
}

$sealedPath = Join-Path $root 'sealed-source-plan.json'
$beforePath = Join-Path $root 'before.json'
$failurePath = Join-Path $root 'failure.json'
$sealed = Get-Json $sealedPath
$before = Get-Json $beforePath
$failure = Get-Json $failurePath
Record-JsonEvidence $sealedPath 'sealed-source-plan.json'
Record-JsonEvidence $beforePath 'before.json'
Record-JsonEvidence $failurePath 'failure.json'

Require-Equal (Get-Property $sealed 'schema' 'sealed plan') 'kairos.adaptive.intraday-source-plan.v1' 'sealed plan schema'
Require-Equal (Get-Property $before 'state' 'before receipt') 'RUNNING' 'before receipt state'
Require-False (Get-Property $before 'economic_evidence_read' 'before receipt') 'before economic_evidence_read'
Require-False (Get-Property $before 'original_plan_or_tapes_changed' 'before receipt') 'before original_plan_or_tapes_changed'
Require-Equal (Get-Property $failure 'state' 'failure receipt') 'FAILED_CLOSED' 'failure state'
Require-Equal (Get-Property $failure 'phase' 'failure receipt') 'WHOLE_ARCHIVE_INTEGRITY' 'failure phase'
Require-Equal (Get-Property $failure 'error_type' 'failure receipt') 'ValueError' 'failure error type'
Require-Equal (Get-Property $failure 'source_error' 'failure receipt') 'row count exceeds configured limit' 'failure detail'
Require-Equal ([string]$failure.archive.symbol) 'BTCUSDT' 'failed archive symbol'
Require-Equal ([string]$failure.archive.day) '2022-06-14' 'failed archive day'
if ([int]$failure.archives_completed -ne 7) { Stop-Audit 'failure receipt must record seven completed archives' }
if ([long]$failure.rows_checked -ne 13214561) { Stop-Audit 'failure receipt completed-row total mismatch' }
if ([long]$failure.compressed_bytes_fetched -ne 244624875) { Stop-Audit 'failure receipt fetched-ZIP byte total mismatch' }
Require-False (Get-Property $failure 'economics_computed' 'failure receipt') 'failure economics_computed'
Require-False (Get-Property $failure 'source_prerequisite_resolved' 'failure receipt') 'failure source_prerequisite_resolved'
Require-Equal (Get-Property $failure 'no_automatic_retry' 'failure receipt') $true 'failure no_automatic_retry'
foreach ($flag in @('TECHNICAL_PAPER_READY', 'PAPER_QUALIFIED', 'ALPHA_READY', 'LIVE_READY')) {
    Require-False (Get-Property $failure.readiness $flag 'failure readiness') "failure readiness.$flag"
}
Require-Equal ([string]$failure.readiness.STRATEGY_POLICY) 'REJECT_ALL' 'failure readiness policy'
if (Test-Path -LiteralPath (Join-Path $root 'result.json')) { Stop-Audit 'failed attempt unexpectedly contains result.json' }

# No separate launch.json exists in this output; before.json is the retained start receipt.
$launchPath = Join-Path $root 'launch.json'
$launchArtifactPresent = Test-Path -LiteralPath $launchPath
if ($launchArtifactPresent) {
    Record-JsonEvidence $launchPath 'launch.json'
    $launch = Get-Json $launchPath
} else {
    $launch = $null
}

$plan = Get-Json $sealedPath
if (@($plan.archives).Count -ne 9 -or @($plan.tapes).Count -ne 4 -or @($plan.candidate_ids).Count -ne 12) {
    Stop-Audit 'sealed plan roster dimensions differ from the fixed protocol'
}
Require-Equal ([string]$plan.purpose) 'SOURCE_ONLY_RECORDED_PRINT_COMPATIBILITY_NOT_EXECUTION_OR_ECONOMICS' 'sealed plan purpose'
Require-Equal ([string]$plan.original_plan_sha256) 'ad07e992a1440f459acb7b8cdb621a54c70ad1119ee9af7f37aceb6966d69f0c' 'original native plan digest'
Require-Equal ([string]$plan.limits.max_rows_each) '5000000' 'fixed per-archive row limit'
Require-Equal ([string]$plan.clock_policy.completion_delay_ms_assumed) '100' 'completion delay policy'
Require-Equal ([string]$plan.clock_policy.transport_delay_ms_assumed) '0' 'transport delay policy'

$actualPlanSha = Get-Sha256 $planFile
Require-Equal $actualPlanSha $expectedPlanSha256 'signed source plan SHA256'
Require-Equal ([string]$before.sources.source_plan_file_sha256) $expectedPlanSha256 'before source-plan SHA256'
Require-Equal ([string]$before.sources.plan_sha256) ([string]$plan.original_plan_sha256) 'before original-plan digest'

$nativeById = @{}
$nativeOrder = [Collections.Generic.List[string]]::new()
$tapeHashes = [Collections.Generic.List[object]]::new()
foreach ($tape in @($plan.tapes)) {
    $nativePath = Join-Path (Join-Path $nativeRoot ([string]$tape.window)) 'decisions.jsonl'
    if (-not (Test-Path -LiteralPath $nativePath -PathType Leaf)) { Stop-Audit "native tape missing: $($tape.window)" }
    $nativeSha = Get-Sha256 $nativePath
    Require-Equal $nativeSha ([string]$tape.sha256) "native tape $($tape.window) SHA256"
    $tapeHashes.Add([pscustomobject]@{ window = $tape.window; sha256 = $nativeSha })
    foreach ($line in [IO.File]::ReadLines($nativePath)) {
        $slot = $line | ConvertFrom-Json
        if ($null -eq $slot.intent) { continue }
        $id = [string]$slot.intent.intent_id
        if ([string]::IsNullOrWhiteSpace($id) -or $nativeById.ContainsKey($id)) { Stop-Audit 'native candidate ID blank or duplicated' }
        $nativeById[$id] = [pscustomobject]@{
            symbol = [string]$slot.intent.symbol
            decision_ts_ms = [long]$slot.intent.decision_ts_ms
        }
        $nativeOrder.Add($id)
    }
}
if ($nativeOrder.Count -ne 12 -or ($nativeOrder -join "`n") -cne (@($plan.candidate_ids) -join "`n")) {
    Stop-Audit 'hashed original tapes do not retain the fixed candidate ID roster/order'
}

$expectedDownloads = @{}
$actualDownloadJsonCount = 0
$zipBytesAllDownloads = [long]0
for ($i = 1; $i -le 8; $i++) {
    $receiptPath = Join-Path $root ("downloads-{0:D2}.json" -f $i)
    $getReceipts = @(Get-Json $receiptPath)
    Record-JsonEvidence $receiptPath ("downloads-{0:D2}.json" -f $i)
    if ($getReceipts.Count -ne 2) { Stop-Audit "downloads-$('{0:D2}' -f $i) must contain one checksum and one ZIP witness" }
    foreach ($get in $getReceipts) {
        $name = [string]$get.filename
        if ($name -ne [IO.Path]::GetFileName($name) -or $expectedDownloads.ContainsKey($name)) { Stop-Audit "unsafe/duplicate GET filename: $name" }
        if ($get.http_status -ne 200 -or $get.requests -ne 1 -or $get.redirects -ne 0) { Stop-Audit "GET was not a single exact HTTP 200 without redirects: $name" }
        $parts = $name -split '-aggTrades-', 2
        if ($parts.Count -ne 2 -or $parts[0] -notin @('BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT')) { Stop-Audit "GET name outside fixed symbol roster: $name" }
        $expectedUrl = "$publicRoot/$($parts[0])/$name"
        Require-Equal ([string]$get.url) $expectedUrl "fixed public URL $name"
        $localFile = Join-Path (Join-Path $root $parts[0]) $name
        if (-not (Test-Path -LiteralPath $localFile -PathType Leaf)) { Stop-Audit "GET file missing: $name" }
        $fileBytes = (Get-Item -LiteralPath $localFile).Length
        if ([long]$get.bytes -ne $fileBytes) { Stop-Audit "GET byte count mismatch: $name" }
        $fileSha = Get-Sha256 $localFile
        Require-Equal $fileSha ([string]$get.sha256) "GET file SHA256 $name"
        if ($name.EndsWith('.zip', [StringComparison]::OrdinalIgnoreCase)) { $zipBytesAllDownloads += $fileBytes }
        $expectedDownloads[$name] = [pscustomobject]@{ get = $get; path = $localFile; sha256 = $fileSha; bytes = $fileBytes }
        $actualDownloadJsonCount++
    }
}
if ($expectedDownloads.Count -ne 16 -or $actualDownloadJsonCount -ne 16) { Stop-Audit 'expected exactly eight complete GET pairs' }
if ($zipBytesAllDownloads -ne [long]$failure.compressed_bytes_fetched) { Stop-Audit 'eight downloaded ZIP sizes do not sum to failure receipt total' }
foreach ($name in @($expectedDownloads.Keys | Where-Object { $_.EndsWith('.zip.CHECKSUM', [StringComparison]::OrdinalIgnoreCase) })) {
    $sidecar = $expectedDownloads[$name]
    $zipName = $name.Substring(0, $name.Length - '.CHECKSUM'.Length)
    if (-not $expectedDownloads.ContainsKey($zipName)) { Stop-Audit "checksum has no matching ZIP witness: $name" }
    $sideBytes = [IO.File]::ReadAllBytes($sidecar.path)
    if ($sideBytes.Length -gt 512) { Stop-Audit "checksum sidecar exceeds fixed bound: $name" }
    $sideText = [Text.Encoding]::ASCII.GetString($sideBytes).Trim()
    $sideFields = @($sideText -split '\s+' | Where-Object { $_ -ne '' })
    if ($sideFields.Count -ne 2 -or $sideFields[0] -notmatch '^[0-9a-fA-F]{64}$' -or $sideFields[1].TrimStart('*') -cne $zipName) {
        Stop-Audit "checksum sidecar content mismatch: $name"
    }
    Require-Equal $sideFields[0].ToLowerInvariant() $expectedDownloads[$zipName].sha256 "sidecar target ZIP SHA $name"
}

$completedRows = [long]0
$completedZipBytes = [long]0
$scoped = @{}
$archiveSourceHashes = [Collections.Generic.List[object]]::new()
for ($i = 0; $i -lt 7; $i++) {
    $planned = $plan.archives[$i]
    $receiptPath = Join-Path $root ("archive-{0:D2}.json" -f ($i + 1))
    $receipt = Get-Json $receiptPath
    Record-JsonEvidence $receiptPath ("archive-{0:D2}.json" -f ($i + 1))
    $symbol = [string]$planned.symbol
    $day = [string]$planned.day
    $zipName = "$symbol-aggTrades-$day.zip"
    $sideName = "$zipName.CHECKSUM"
    Require-Equal ([string]$receipt.schema) 'kairos.intraday-reference-scan.v1' "archive receipt schema $symbol/$day"
    Require-Equal ([string]$receipt.symbol) $symbol "archive receipt symbol $symbol/$day"
    Require-Equal ([string]$receipt.day) $day "archive receipt day $symbol/$day"
    Require-Equal ([string]$receipt.archive_filename) $zipName "archive receipt filename $symbol/$day"
    if (-not $expectedDownloads.ContainsKey($zipName) -or -not $expectedDownloads.ContainsKey($sideName)) { Stop-Audit "completed archive lacks its GET pair: $symbol/$day" }
    $zip = $expectedDownloads[$zipName]
    $sidecar = $expectedDownloads[$sideName]
    Require-Equal ([string]$receipt.archive_sha256) $zip.sha256 "receipt/archive SHA $symbol/$day"
    Require-Equal ([string]$receipt.checksum_sidecar_sha256) $sidecar.sha256 "receipt/sidecar SHA $symbol/$day"
    if ([long]$receipt.archive_bytes -ne $zip.bytes) { Stop-Audit "receipt/archive bytes mismatch $symbol/$day" }
    if ([string]$receipt.member_filename -cne "$symbol-aggTrades-$day.csv") { Stop-Audit "receipt member mismatch $symbol/$day" }
    $sideText = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($sidecar.path)).Trim()
    if ($sideText.Length -gt 512) { Stop-Audit "checksum sidecar exceeds fixed bound $symbol/$day" }
    $sideFields = @($sideText -split '\s+' | Where-Object { $_ -ne '' })
    if ($sideFields.Count -ne 2 -or $sideFields[0] -notmatch '^[0-9a-fA-F]{64}$' -or $sideFields[1].TrimStart('*') -cne $zipName) {
        Stop-Audit "checksum sidecar content mismatch $symbol/$day"
    }
    Require-Equal $sideFields[0].ToLowerInvariant() $zip.sha256 "sidecar/archive SHA $symbol/$day"
    $completedRows += [long]$receipt.rows
    $completedZipBytes += $zip.bytes
    $archiveSourceHashes.Add([pscustomobject]@{ scope = "$symbol/$day"; archive_sha256 = $zip.sha256; checksum_sha256 = $sidecar.sha256; archive_bytes = $zip.bytes })

    foreach ($record in @($receipt.requests)) {
        $id = [string]$record.intent_id
        if ($scoped.ContainsKey($id)) { Stop-Audit "duplicate completed candidate witness: $id" }
        if (-not $nativeById.ContainsKey($id)) { Stop-Audit "completed archive references unknown candidate: $id" }
        Require-Equal ([string]$nativeById[$id].symbol) $symbol "candidate symbol $id"
        Require-Equal ([string]$nativeById[$id].decision_ts_ms) ([string]$record.decision_ts_ms) "candidate decision timestamp $id"
        $decision = [long]$record.decision_ts_ms
        $eligible = [long]$record.entry_eligible_ts_ms
        $expiry = [long]$record.expires_ts_ms
        $completion = [long]$record.completion_ts_ms_assumed
        $transport = [long]$record.transport_delay_ms_assumed
        if ($eligible -ne $decision + 1 -or $expiry -ne $decision + 60000 -or $completion -ne $decision + 100 -or $transport -ne 0) {
            Stop-Audit "native entry lifetime/completion geometry mismatch $id"
        }
        $arrival = [Math]::Max($eligible, $completion) + $transport
        if ([long]$record.arrival_ts_ms_assumed -ne $arrival) { Stop-Audit "assumed arrival mismatch $id" }
        if ([DateTimeOffset]::FromUnixTimeMilliseconds($eligible).UtcDateTime.ToString('yyyy-MM-dd') -cne $day) {
            Stop-Audit "candidate assigned to wrong UTC archive day $id"
        }
        if ($allowedStatuses -cnotcontains [string]$record.status) { Stop-Audit "unknown status $($record.status)" }
        if ($record.status -eq 'RECORDED_PRINT_REFERENCE') {
            if ($null -eq $record.first_reference -or -not (Test-PositiveDecimal $record.first_reference.price)) {
                Stop-Audit "recorded print missing a positive decimal price $id"
            }
            $ref = $record.first_reference
            $refTime = [long]$ref.transact_time_ms
            if ($refTime -lt $arrival -or $refTime -gt $expiry) { Stop-Audit "print outside inclusive assumed lifetime $id" }
            if ([long]$record.wait_ms -ne $refTime - $arrival) { Stop-Audit "wait_ms mismatch $id" }
            if ($null -eq $record.immediate_predecessor -or
                [long]$record.immediate_predecessor.aggregate_trade_id + 1 -ne [long]$ref.aggregate_trade_id -or
                [long]$record.immediate_predecessor.transact_time_ms -gt $refTime) {
                Stop-Audit "immediate predecessor witness inconsistent $id"
            }
            if ($null -eq $record.strict_pre_window_predecessor -or [long]$record.strict_pre_window_predecessor.transact_time_ms -ge $arrival) {
                Stop-Audit "strict pre-window witness invalid $id"
            }
            if ($null -eq $record.strict_post_window_successor -or [long]$record.strict_post_window_successor.transact_time_ms -le $expiry) {
                Stop-Audit "strict post-window witness invalid $id"
            }
            if ([bool]$record.aggregate_gap_intersects_window) { Stop-Audit "recorded print marked aggregate-gap tainted $id" }
        }
        $scoped[$id] = [pscustomobject]@{ symbol = $symbol; day = $day; record = $record }
    }
}
if ($completedRows -ne 13214561 -or $completedRows -ne [long]$failure.rows_checked) { Stop-Audit 'completed archive row total does not match failure receipt' }
if ($completedZipBytes -ge $zipBytesAllDownloads) { Stop-Audit 'failed archive ZIP bytes were not separated from completed archive bytes' }

$unresolved = [Collections.Generic.List[object]]::new()
foreach ($id in @($plan.candidate_ids)) {
    if (-not $scoped.ContainsKey([string]$id)) {
        if (-not $nativeById.ContainsKey([string]$id)) { Stop-Audit "unknown candidate in sealed plan: $id" }
        $candidate = $nativeById[[string]$id]
        $candidateDay = [DateTimeOffset]::FromUnixTimeMilliseconds($candidate.decision_ts_ms + 1).UtcDateTime.ToString('yyyy-MM-dd')
        $plannedScope = @($plan.archives | Where-Object { $_.symbol -ceq $candidate.symbol -and $_.day -ceq $candidateDay })
        $reason = if ($plannedScope.Count -eq 1 -and $candidateDay -eq '2022-06-14' -and $candidate.symbol -ceq 'BTCUSDT') {
            'FAILED_ARCHIVE_ROW_LIMIT_PREFIX_UNKNOWN'
        } elseif ($plannedScope.Count -eq 1 -and $candidateDay -eq '2022-06-14' -and $candidate.symbol -ceq 'ETHUSDT') {
            'NOT_REACHED_AFTER_FAILED_ARCHIVE'
        } else {
            'NO_COMPLETED_ARCHIVE_WITNESS'
        }
        $unresolved.Add([pscustomobject]@{ intent_id = [string]$id; symbol = $candidate.symbol; day = $candidateDay; reason = $reason })
    }
}
if ($scoped.Count + $unresolved.Count -ne 12) { Stop-Audit 'completed and unresolved candidates do not partition original roster' }

$completedStatusCounts = @{}
foreach ($entry in $scoped.Values) {
    $status = [string]$entry.record.status
    if (-not $completedStatusCounts.ContainsKey($status)) { $completedStatusCounts[$status] = 0 }
    $completedStatusCounts[$status]++
}
$jsonHashes = @($evidenceFiles)
$report = [ordered]@{
    schema = 'kairos.adaptive.independent-partial-intraday-witness-audit.v1'
    state = 'PASSED_PARTIAL_WITNESSES'
    scope = 'Independent partial receipt, native tape, byte hash, and retained-witness arithmetic only; no ZIP decompression or parser rerun.'
    source_prerequisite_resolved = $false
    complete = $false
    global_before_after_source_equality_proven = $false
    original_plan_sha256 = [string]$plan.original_plan_sha256
    fixed_source_plan_sha256 = $actualPlanSha
    auditor_sha256 = Get-Sha256 $PSCommandPath
    exact_original_json_hashes = $jsonHashes
    native_tape_sha256_verified = @($tapeHashes)
    launch_artifact_present = $launchArtifactPresent
    launch_binding = if ($launchArtifactPresent) { 'Separate launch JSON present and hashed.' } else { 'No separate launch.json exists; before.json start receipt and failure.json are retained.' }
    original_candidates = 12
    completed_candidate_witnesses = $scoped.Count
    unresolved_candidate_ids = @($unresolved)
    completed_archives = 7
    downloaded_pairs = 8
    completed_archive_rows = $completedRows
    completed_archive_zip_bytes = $completedZipBytes
    all_downloaded_zip_bytes = $zipBytesAllDownloads
    failure_receipt_rows_checked = [long]$failure.rows_checked
    failed_archive = [ordered]@{
        symbol = [string]$failure.archive.symbol
        day = [string]$failure.archive.day
        error = [string]$failure.source_error
        configured_row_limit = [long]$plan.limits.max_rows_each
        failed_archive_prefix_rows = $null
        failed_archive_prefix_status = 'UNKNOWN_NOT_RETAINED; do not add to completed archive row total'
        whole_member_crc_verified = $false
    }
    completed_reference_statuses = $completedStatusCounts
    source_file_hashes = @($archiveSourceHashes)
    qualification = [ordered]@{
        quote_observed = $false
        fill_qualified = $false
        capacity_qualified = $false
        economics_computed = $false
        selection_credit = $false
        native_context_freshly_requalified = $false
        winner = $null
        readiness = 'REJECT_ALL'
    }
    limitations = @(
        'The 13,214,561 rows are additive counts from seven completed archive scans only; the failed BTCUSDT 2022-06-14 scan prefix is unknown and excluded.',
        'Eight downloaded ZIPs and sidecars are byte-hashed against retained GET witnesses; this audit does not decompress ZIP members, rerun CRC, or independently verify CSV earliest-print ordering.',
        'No final result.json or successful after-source check exists; no global source non-mutation claim is made.',
        'Published aggregate prints are not BBO, local receive time, our fills, capacity, execution coverage, or economic performance.',
        'Unresolved candidates remain source-incomplete evidence, not losses, invalid performance, or a strategy result.'
    )
    audited_utc = [DateTimeOffset]::UtcNow.ToString('o')
}

$json = ConvertTo-Json -InputObject $report -Depth 16
$stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
    try { $writer.WriteLine($json) } finally { $writer.Dispose() }
} finally { if ($stream) { $stream.Dispose() } }
Write-Output 'Partial witness audit: PASSED_PARTIAL_WITNESSES'
Write-Output "Receipt: $output"
Write-Output "Completed rows: $completedRows; completed archive ZIP bytes: $completedZipBytes; all downloaded ZIP bytes: $zipBytesAllDownloads"
Write-Output "Completed candidate witnesses: $($scoped.Count); unresolved: $($unresolved.Count)"
